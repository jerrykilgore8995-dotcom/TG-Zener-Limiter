# TG / EMI-Style Zener Limiter — 10k Reference / 1% Controls

**Handoff version 1.2 (SIDECHAIN RIPPLE REPAIR), 2026-11-11.** This ZIP is for a CODING AI to integrate into a TG-style limiter. It contains compilable, tested C++17 DSP reference code, original recovered 10 kΩ legacy data, 101-position reference tables, actual 101-position DSP renders, acceptance tests, and a precise implementation brief. It is **not a compiled VST3**.

## Mandatory behavior

| Section | Exact requested behavior | Implementation / status |
|---|---|---|
| Operating mode | LIMIT only | Implemented |
| Ratio | Exactly 8:1 above knee | Implemented and automatically tested; not represented as a manufacturer-certified universal ratio |
| Knee switch | HARD=0 dB / SOFT=3 dB | Implemented; mathematical quadratic knee |
| Attack | 8 ms fixed | 8 ms detector charging **time constant**, not a proved 10–90% audio attack time; new separate 13 ms crest-hold BEFORE RC |
| Recovery switch | 50, 100, 250, 500, 1000, 2000 ms | Implemented and detector-timing tested **after 13 ms crest hold**; default position 2 (100 ms) |
| Input | 0..100%, 1%-steps, digital pre-cell gain | −18 to +18 dB, 50%=0dB (calibrated from legacy 10 kΩ sweep) |
| Output | 0..100%, 1%-steps, *pure digital* post-cell gain/makeup | −24 to +24 dB, 50%=0dB; no output transformer/saturation |
| Limiting range | At least 20 dB available | Confirmed **20.999856 dB** at 100% Input with −18 dBFS 1 kHz reference (hard knee). Limiting continues beyond 20dB with hotter signals |
| GR meter | 0..20 dB graduated; >20 dB in RED | Meter maps 0–20 to [0,1], reports actual uncapped applied GR separately, exposes red over-range |
| Sidechain ripple | **NEW: 13ms causal crest-hold before attack/release RC**, no audio-path filter | At 100Hz, K3/K5 from gain modulation now below analysis reporting floor; also suppressed at 40–200Hz with saturation disabled; 13ms release hold is disclosed |
| Zener character | Existing 10 kΩ spectral reference only | **Experimental full-chain K2–K5 fingerprint**, interpolated to 1% and DSP-rendered; **not exact isolated SPICE-cell modeling** |

**NO physical analog models on Input or Output.** The goal is: `[DIGITAL Input gain] -> [one gain-control/dynamic + zener-character cell] -> [DIGITAL Output gain/makeup]`. Do not add transformers, PSU, input/output nonlinearities or an additional limiter in this module. Inserting into a larger limiter is allowed, but never double-count full-chain harmonics.

## Important provenance boundary

The only recovered source data are TG1 v1.3 **complete-chain** 10 kΩ-sweep results at **11 sampled knob positions** (0, 10, ..., 100%). The new `reference/10k_reference_101_positions.csv` preserves those eleven true *legacy simulation* anchors and creates **90 mathematically interpolated, NOT MEASURED** intermediate positions. The source CSV is not the actual isolated zener cell and does not prove analog TG1 fidelity. An old sweep cannot be made into an *exact SPICE fit* solely by requesting 1%-step interpolation.

The supplied DSP code emits a close **1 kHz spectral preview** using those 10 kΩ K2–K5 magnitudes, but K6–K20, harmonic phases, true circuit hysteresis and multi-tone behavior are unavailable. At higher drive the legacy full-chain K3 reaches ~10.29% of K1 at the old 100% anchor; **this is not a verified original EMI zener gain-cell value**. `legacy10kResidual` is enabled so the user can audition this provisional character. A coding AI must REPLACE it with a correctly validated isolated-cell fit when original SPICE netlist, waveforms or hardware data are supplied. See `docs/CODING_AI_INSTRUCTIONS.md`.

## Sidechain repair (new v1.2)

Previously the detector simply attack/release-smoothed each sample of `abs(audio)`.
At 100Hz full-wave rectification creates 200Hz modulation of the gain, leaking into audio as K3 and K5.
The repair adds a causal **13ms sliding-window peak/crest hold**, applied **only to the sidechain envelope input**. A monotonic deque evaluates the peak with amortized O(1) work/sample, no audio-buffer delay, no external libraries, no allocations in the audio callback. The existing 8ms attack and six selectable recovery RC coefficients are unchanged.

**Important:** the 13ms hold postpones the START of release by up to 13ms on abrupt signal drops. Thus 100ms means 100ms release *time constant after hold*, not exactly 100ms since the source stops. It is an intentionally simplified detector anti-ripple approach, **not an isolated SPICE reproduction** of EMI's D11/R50/C12 reservoir network. Original EMI handbook section 12.22.3 confirms the charge/discharge reservoir is C12; there is no need to put an extra coupling capacitor or lowpass into the audio path. For true analog match, replace this with an independently calibrated control-voltage fit to the original SPICE waveform.

At 100Hz with a −18dBFS sine, **zener residual disabled**, input=50%: former K3 −70.36dBFS and K5 −84.05dBFS; repaired both below the **−240 dBFS numerical reporting floor** of the DFT analyzer. At input=100%: old K3 −68.11dBFS and K5 −81.80dBFS; repaired both below −240dBFS floor. This does **not** represent physical noise floor or true analog distortion. Signal-phase, harmonics and GR are verified in `validation/actual_dsp_100Hz_low_level_after_ripple_fix.csv` (24 actual renders including −36/−30/−18 dBFS source). No user-defined 100Hz saturation target has been implemented yet.

With `legacy10kResidual=true`, the existing full-chain/1kHz fingerprint still generates significant 100Hz harmonic distortion at high drive (100% Input: K3 about −40.75 dBFS and K5 about −63.29 dBFS); this is **not detector ripple**. It is NOT the newer user-specified 100Hz target of K3 −76 dBFS. Do not present it as calibrated 100Hz saturation. The remaining 100Hz model must be fitted separately after the ripple repair.

## Test matrix included

- `reference/legacy_harmonics_10000ohm.csv` — actual 11-position 10 kΩ v1.3 *full-chain* simulator data.
- `reference/10k_reference_101_positions.csv` — 101 rows, of which **11 anchors** and **90 interpolation-only rows**.
- `validation/actual_dsp_input_101step_10k_preview.csv` — 101 real DSP renders at 1 kHz, 44.1 kHz, −18 dBFS input source, Output=50%, 100ms recovery, hard knee.
- `validation/actual_dsp_output_101step_10k_preview.csv` — 202 real DSP renders for **Input 50% and 100%**, both with Output 0..100 in 1%-steps.
- `validation/test_design.cpp` — 8:1 ratio and overrange, both knees, 101 positions for each knob, 8ms and six recovery coefficients, meter behavior.
- `validation/verify_reports.py` — verifies all 101/202 output rows and calibration preview tolerances.
- `validation/render_low_frequency_clean.cpp` and `validation/actual_dsp_100Hz_low_level_after_ripple_fix.csv` — independent 100Hz steady-state harmonic tests at three source levels and 4 input positions with saturation ON/OFF.
- `validation/original_v1p1_100Hz_baseline.csv` — compiled previous reference DSP output before anti-ripple repair.
- `validation/verify_ripple_fix.py` — checks sidechain ripple and clean-audio K2–K6.
- `validation/test_subbass_ripple.cpp`, `validation/actual_dsp_40to200Hz_clean_ripple_sweep.csv` — checks 40–200Hz with −18dBFS source and 100% input, no harmonic preview.

Measurements at 1% positions are actual **new DSP renders**; the *reference targets at those positions* are interpolated, not additional SPICE measurements.

## Compile / regenerate / verify (C++17 & Python 3)

From the extracted ZIP directory:

```bash
python3 tools/make_101_targets.py
g++ -std=c++17 -O2 -Wall -Wextra -pedantic validation/test_design.cpp -o /tmp/tg_design_test
/tmp/tg_design_test
g++ -std=c++17 -O3 -Wall -Wextra -pedantic validation/render_101_steps.cpp -o /tmp/tg_render_101
/tmp/tg_render_101
python3 validation/verify_reports.py
```

No external libraries, audio callback allocation, SPICE/ODE/Newton solve, analog PSU solver, transformer model or input/output waveshapers. This reference currently uses standard logarithm/power functions to implement the detector/gain law; the integrating AI may optimize those **only after** validating exact static transfer and audio metrics.

## Files

- `src/TGZenerLimiter.h` — C++17 reference component with 101 discrete digital control positions, 8:1 knee law, six recovery times and uncapped GR meter.
- `src/LegacyHarmonicAnchors.h` — **10 kΩ only**, no 600Ω profile used.
- `docs/CODING_AI_INSTRUCTIONS.md` — precise mandatory integration and future SPICE fit plan.
- `docs/ISOLATED_CELL_REFERENCE_TEMPLATE.csv` — dataset schema to replace placeholders with true isolated-cell SPICE/hardware solves.
- `docs/MEASUREMENT_RESULTS.md` — numeric reproducible test results and accuracy limitations.

The designer requested a simple, low-CPU model. **The static control law and digital controls are implemented; full circuit equivalence is not established without the isolated source model.**
