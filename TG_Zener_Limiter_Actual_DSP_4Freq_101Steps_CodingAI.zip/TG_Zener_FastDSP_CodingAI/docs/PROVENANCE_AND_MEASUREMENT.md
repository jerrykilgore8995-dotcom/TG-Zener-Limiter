# Source provenance and reproducibility

- `reference/GainCell.h` plus `reference/Nodal.h`: retrieved from user's archived `TG1-Gain-Cell-Source.zip` / v1.3 solver. This is the original reference engine, NOT used by real-time audio DSP.
- `reference/original_TGZener4FreqReference.bin`: original isolated-cell numerical solver K1-K20 complex phasor reference, four frequencies, 101 input points, 17 bias settings, unchanged source harmonic amounts.
- `reference/original_measurements/cell_*`: original complex coefficient CSVs measured at 100Hz/1000Hz/5000Hz/10000Hz, source units V and dBc, NOT dBFS or full-chain hardware measurements.
- `reference/TGZener4Freq_THD2pct_InputScaled.bin`: user-requested rescaled target: each position K2-K20 multiplied by common scalar so K2-K20 THD = 0.02*inputPercent (percent), while retaining K1 and each original relative harmonic complex phase/balance. This table has NOT become an unmodified physical cell measurement.
- `reference/original_measurements/LEGACY...`: older 10k-ohm **full-chain** sweep, not isolated cell output; kept for historical traceability, not blended into nonlinear target.

Input calibration used by the original cell measurements: peak input V = 0.05×10^((-18+0.36*inputPercent)/20). The user plugin uses a -18dBFS sine, -18..+18dB input control, fixed +14dB preamp and 0.07943282347242815V per post-preamp digital FS to reproduce original nominal cell drive conditions. Different program levels are mapped into the nearest measured control surfaces; that behavior is approximate outside the exact reference levels.

The 6,868-point rendered test forces the reference tone frequency and reference bias to measure a precise frequency/bias/input anchor with the DSP sample processor. It also primes the sidechain to steady peak, to remove the startup transient from the spectral comparison. These reference-only hooks do not appear in normal plugin operation. The tests measure K1-K20 using complex DFT after multiple settled cycles.

Harmonics weaker than -140dBc are excluded from *max relative phase / magnitude error* statistics because low-level numerical sidelobes make their phase ill-conditioned; THD still uses all K2-K20. At 5k/10k the offline test sample rates are 220.5/441kHz. The gain cell frequency magnitudes and phases between measured anchors are interpolated; no source measurement proves intermediate-frequency precision.

This C++ DSP synthesizes harmonics from a dominant tone estimate and a measured complex surface, which can match the measured steady sinusoidal spectrum extremely closely. It is not a general physical nonlinear circuit transformation for complex waveforms; full multitone nonlinear cross-products are NOT matched, and avoiding them can make dynamic behavior unlike actual zeners. This should be addressed by future Volterra/multiband or equivalent kernels and real circuit comparisons before labeling this a faithful analog model.
