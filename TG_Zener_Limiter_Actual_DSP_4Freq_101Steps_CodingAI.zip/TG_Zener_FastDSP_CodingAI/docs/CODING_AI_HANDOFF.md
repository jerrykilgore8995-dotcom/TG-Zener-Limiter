# CODING AI — integrate the COMPLETED C++ DSP, not another placeholder

The user requested an actual lightweight DSP replacement with measured four-frequency zener harmonic targets and a simplified 8:1 limiter. **The core DSP is already implemented and tested** in `src/TGFastZenerLimiter.h`, with reference loaded by `src/TGReferenceGrid.h`. These sources compile and render actual audio in supplied tests.

## Required VST3 handoff behavior

- Port the two source headers unchanged initially, building as a JUCE or standard VST3 C++ processor. Keep the supplied measured binary as an embedded resource (2.25MB) or robustly packaged readonly file; decode/load it at plugin construction, NEVER in the audio thread. Avoid exposing reference-only test APIs as user-facing controls.
- Mono audio core is ready; for stereo either dual mono or implement correct linked detector (max L/R peaks). Test both modes, avoid unintended stereo image shifts. The legacy user primarily wants the limiter mode.
- Input UI: 0..100%, 1% steps mapped from -18 to +18dB; fixed +14dB pre-gain included after knob; output -24..+24dB in 1% steps (50%=unity); stable 5ms digital smooth. Output is makeup and cannot affect relative harmonic distortion.
- Limiter sidechain: 8:1, switchable 0dB hard knee / 3dB soft, fixed 8ms RC attack, six recovery indices [50,100,250,500,1000,2000]ms, 13ms sidechain-only crest hold. Accurate meter: commanded gain reduction, 20dB face, red overrange. At max input and -18dBFS pure 1k tone, default threshold produces 20dB GR; hotter input may produce more.
- Four frequencies 100/1000/5000/10000Hz, all 101 input percentages, all 17 reference bias settings: normalized K2..K20 to 0.02% THD per 1% knob, measured harmonic *balance and relative phase* retained, K1 frequency response and phase. The normalized binary derives from the original circuit solver. Do NOT add a second arbitrary distortion stage.
- Fixed-frequency test hooks produce precise match across full 6868 grid; DO NOT claim precise on real music until additional wideband IMD/transient circuit reference work has been done. The dominant-sine detector is a provisional broadband program-audio solution, not a true analog wave-shaping equivalent. Prioritize generalizing the audio-character path to causal wideband DSP without losing the measured 6868-point calibration.

## Production work still needed (do not conceal)

1. **Multitone surrogate**: build a 2-tone and 3-tone circuit solver reference (e.g. 100+1000Hz, 1000+1500Hz, transient steps), fit IMD and harmonic phase plus dynamic gain, and prove a revised nonlinear module preserves all existing single-tone results.
2. **Alias control**: implement oversampling filtering and CPU/latency tests at 44.1/48/88.2/96kHz; at 44.1k skip >Nyquist harmonics. State that full THD K2–K20 at 10k needs >=400kHz sample rate offline; cannot promise 2% audio-band THD at host44.1k.
3. **End-to-end**: host automation smoothing, silence/denormals, stereo linking, click-free reset, float/double, meter ballistics, actual 8ms dynamic response and six release-decay traces, audio/video host compatibility, 100-instance CPU tests, no memory allocations/locks in callback.
4. Provide Windows x64 VST3, build source, measured analyzer reports and reproducible test WAVs when user requests a built VST. This ZIP itself is DSP source+tests, not a compiled VST3.

## Acceptance metrics

`results/full_6868_rendered_complex_validation.csv` contains all points and rendered K1–K20 ratio comparison. All rendered points include multiple cycles after sufficient steady-state warmup. Max observed magnitude error 0.000023dB and relative phase error 0.000140deg (above -140dBc). This exactness is at reference pure tones with a validation-supplied frequency, NOT proof of IMD. Re-run tests after any changes.

## Do not regress

- Do not reintroduce the original Newton/nodal solver inside the audio callback.
- Do not re-introduce the old legacy K2–K5 ladder or a fake waveshaper.
- Do not create sidechain-generated low-frequency harmonic ripple. With saturation off, 100Hz K3 is below numeric floor in supplied test.
- Do not hard-clip the GR at 20dB or make makeup affect meter.
- Do not equate 13ms hold to the nominal 8ms attack time.
- Do not call the normalized THD values unmodified original solver values.
