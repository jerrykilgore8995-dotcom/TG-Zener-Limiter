#pragma once

#include "../../GainBrainMkII/Source/Nodal.h"

namespace tg1 {

// TG-family gain cell with input/reference followers and VT24 current sink.
class GainCell {
    enum Node { left, right, leftMiddle, rightMiddle, z1, z2, z3, z4,
                leftEmitter, rightEmitter, tail, sinkEmitter, referenceBase, signalBase, referenceDrive, inputBase, overloadBase, overloadCollector, count };
    using Net = gainbrain::Nodes<count>;
    static constexpr auto g = Net::ground;
    static constexpr auto plus = Net::rail21;
    static constexpr auto minus = Net::rail24;

public:
    explicit GainCell(double sampleRate) : dt(1 / sampleRate)
    {
        net.regulated = 20;
        net.main = -20;
        net.voltage = {10, 10, 15, 15, 20, 15, 20, 15, 6, 6, 5, -19.5, 6.7, 6.7, 6.1, 6.1, -6.7, -20};
        // Trim the reference source against the signal follower at DC.
        // The scan specifies selected-on-test parts without final values.
        for (int i = 0; i < 8; ++i) {
            solve(0, benchBias(.15e-3), 0, true);
            if (i < 7) referenceVoltage += net.voltage[signalBase] - net.voltage[referenceBase];
        }
        for (int i = 0; i < 6; ++i) {
            solve(0, benchBias(1.2e-3), 0, true);
            zenerTrim = std::clamp(zenerTrim - 1500 * (net.voltage[left] - net.voltage[right]), 2.0, 100.0);
            solve(0, benchBias(.15e-3), 0, true);
            referenceVoltage += net.voltage[signalBase] - net.voltage[referenceBase];
        }
        solve(0, benchBias(.15e-3), 0, true);
        inputDc = net.voltage[inputBase];
    }

    double step(double input, double tailSetting, double positive = 20, double negative = -20)
    {
        net.regulated = positive;
        net.main = negative;
        solve(input, benchBias(tailSetting), dt);
        return net.voltage[left] - net.voltage[right];
    }

    void process(double input, double controlBias, double positive, double negative)
    {
        net.regulated = positive;
        net.main = negative;
        solve(input, controlBias, dt, true);
    }
    double leftVoltage() const { return net.voltage[left]; }
    double rightVoltage() const { return net.voltage[right]; }

    struct OperatingPoint {
        double leftCollector, rightCollector, tail, sinkEmitter, sinkCurrent;
        double leftVce, rightVce, sinkVce, leftBase, rightBase;
    };
    OperatingPoint operatingPoint() const
    {
        const auto& v = net.voltage;
        return {v[left], v[right], v[tail], v[sinkEmitter], (v[sinkEmitter] - net.main) / 4700
            + (v[overloadCollector] - net.main) / 1500,
            v[left] - v[leftEmitter], v[right] - v[rightEmitter], v[tail] - v[sinkEmitter], v[referenceBase], v[signalBase]};
    }

    uint64_t iterations() const { return net.iterationsUsed; }
    unsigned failures() const { return net.failures; }

private:
    double benchBias(double requested) const
    {
        return net.main + 4700 * requested + .02585 * std::log(requested / bc109.is);
    }

    void solve(double input, double controlBias, double timestep, bool coupled = false)
    {
        net.dt = timestep;
        net.in = controlBias;
        net.fixed = coupled ? input : inputDc + input;
        net.third = referenceVoltage;
        net.solve([&] {
            // Eliminate the two unloaded resistor junctions analytically.
            net.resistor(plus, z1, 24 + 12); // R16 and D1 series resistance
            net.resistor(plus, z3, zenerTrim + 12); // AOT8/AOT10 and D3 resistance
            avalanche(z1, leftMiddle); // D1
            net.resistor(leftMiddle, z2, 12);
            avalanche(z2, left); // D2
            avalanche(z3, rightMiddle); // D3
            net.resistor(rightMiddle, z4, 12);
            avalanche(z4, right); // D4

            net.resistor(leftEmitter, tail, 3900);
            net.resistor(rightEmitter, tail, 3900);
            net.resistor(sinkEmitter, minus, 4700);
            // VT27 overload shunt. The divider targets the CE226 -6.7 V reference.
            net.resistor(overloadBase, g, 12000);
            net.resistor(overloadBase, minus, 24000);
            net.resistor(overloadCollector, minus, 1500);
            net.transistor(overloadCollector, overloadBase, sinkEmitter, bcy71);
            net.resistor(plus, referenceBase, 20000);
            net.resistor(plus, signalBase, 20000);
            net.transistor(g, referenceDrive, referenceBase, bcy71); // VT4
            net.resistor(plus, inputBase, 46000);
            net.resistor(inputBase, g, 20000);
            if (coupled) {
                net.capacitor(Net::fixedSource, inputBase, 4.7e-6, previousInput, true); // C1
                net.capacitor(inputBase, g, 220e-12); // C25
            }
            net.transistor(g, coupled ? inputBase : Net::fixedSource, signalBase, bcy71);
            net.transistor(left, referenceBase, leftEmitter, bc109);
            net.transistor(right, signalBase, rightEmitter, bc109);
            net.transistor(tail, Net::signal, sinkEmitter, bc109);
            net.resistor(Net::thirdSource, referenceDrive, 27000); // R12
            net.capacitor(referenceDrive, g, 4.7e-6); // C5
        }, timestep == 0 ? 180 : 45, coupled);
        previousInput = input;
    }

    void avalanche(int cathode, int anode)
    {
        // Fit to 1N751A nominal 5.1 V at 20 mA and 17 ohm maximum
        // small-signal impedance at that test current. Knee and Cj are
        // estimates pending a low-current sweep of the selected pair.
        constexpr double knee = .09, vReference = 4.86, iReference = .020;
        constexpr double vt = .045, forwardIs = 2.5e-9;
        const double v = net.voltage[cathode] - net.voltage[anode];
        const double reverse = (v - vReference) / knee;
        const double forward = -v / vt;
        const double i = iReference * Net::junction(reverse) - forwardIs * (Net::junction(forward) - 1);
        const double conductance = iReference * Net::junctionSlope(reverse) / knee
                                  + forwardIs * Net::junctionSlope(forward) / vt;
        net.branch(cathode, anode, i, conductance);
        net.capacitor(cathode, anode, 80e-12);
    }

    static constexpr gainbrain::Bjt bc109{7e-15, 300, 4, 80, 10e-12, 4e-12, 1, .05, 0, .5e-9};
    static constexpr gainbrain::Bjt bcy71{1.5e-14, 150, 4, 55, 14e-12, 6e-12, -1, .07, 0, .8e-9};
    Net net;
    double dt, referenceVoltage = 6.0, previousInput = 0, inputDc = 6.1, zenerTrim = 24;
};

} // namespace tg1
