#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace gainbrain {
struct Bjt {
    double is, beta, reverseBeta, early, cbe, cbc;
    double polarity = 1, knee = 1, leakage = 0, transit = 0;
};

// Forward transport, reverse transport and Early modulation. The 2N5089
// values are from Fairchild; the other devices use datasheet-constrained fits.
inline constexpr Bjt q5089{5.911e-15, 1122, 1.271, 62.37, 4.973e-12, 4.017e-12,
                           1, .01492, 5.911e-15, .8217e-9};
inline constexpr Bjt q6520{5e-15, 390, 2, 70, 8e-12, 4e-12};
inline constexpr Bjt q6512{7e-15, 160, 3, 65, 10e-12, 5e-12};
inline constexpr Bjt qA10{1e-14, 130, 3, 90, 15e-12, 6e-12};
inline constexpr Bjt qA13{8e-15, 140, 3, 80, 18e-12, 6e-12};
inline constexpr Bjt qA70{1.4e-14, 120, 3, 60, 12e-12, 5e-12, -1};
inline constexpr Bjt qA65{1.3e-14, 115, 3, 70, 20e-12, 7e-12, -1};

template<int size>
struct Nodes {
    using Vector = std::array<double, size>;
    using Matrix = std::array<std::array<double, size + 1>, size>;
    static constexpr int ground = -1, signal = -2, rail21 = -3, rail24 = -4, fixedSource = -5, thirdSource = -6;
    Vector voltage{}, previous{};
    Matrix matrix{};
    double in = 0, fixed = 0, third = 0, regulated = 21, main = 24, dt = 0;
    unsigned failures = 0;
    uint64_t iterationsUsed = 0;
    struct Junction { int a, b; double polarity; };
    std::array<Junction, 32> junctions{};
    unsigned junctionCount = 0;

    double at(const Vector& nodes, int n) const
    {
        switch (n) {
            case ground: return 0;
            case signal: return in;
            case fixedSource: return fixed;
            case thirdSource: return third;
            case rail21: return regulated;
            case rail24: return main;
            default: return nodes[static_cast<size_t>(n)];
        }
    }

    void stamp(int n, int a, int b, double current, double slope)
    {
        if (n < 0) return;
        if (a >= 0) matrix[n][a] += slope;
        if (b >= 0) matrix[n][b] -= slope;
        matrix[n][size] -= current;
    }

    void branch(int a, int b, double current, double slope)
    {
        stamp(a, a, b, current, slope);
        stamp(b, a, b, -current, -slope);
    }

    void resistor(int a, int b, double resistance)
    {
        const auto g = 1 / resistance;
        branch(a, b, g * (at(voltage, a) - at(voltage, b)), g);
    }

    void capacitor(int a, int b, double farads, double externalPrevious = 0, bool fixedIsSignal = false)
    {
        if (dt == 0) return;
        const auto g = farads / dt;
        const auto priorA = (a == signal || (fixedIsSignal && a == fixedSource)) ? externalPrevious : at(previous, a);
        const auto priorB = (b == signal || (fixedIsSignal && b == fixedSource)) ? externalPrevious : at(previous, b);
        branch(a, b, g * (at(voltage, a) - at(voltage, b) - priorA + priorB), g);
    }

    static double junction(double x)
    {
        // Linear continuation keeps the Jacobian defined during overload.
        constexpr double edge = 36, expEdge = 4311231547115195.;
        return x <= edge ? std::exp(std::max(-70., x)) : expEdge * (1 + x - edge);
    }

    static double junctionSlope(double x)
    {
        return std::exp(std::clamp(x, -70., 36.));
    }

    static double junctionFromSlope(double x, double slope)
    {
        return x <= 36. ? slope : slope * (1 + x - 36.);
    }

    void diode(int a, int b)
    {
        junctions[junctionCount++] = {a, b, 1};
        constexpr double is = 2.52e-9, vt = .04531;
        const auto x = (at(voltage, a) - at(voltage, b)) / vt;
        const auto slope = junctionSlope(x);
        branch(a, b, is * (junctionFromSlope(x, slope) - 1), is * slope / vt);
        capacitor(a, b, 4e-12);
    }

    void transistor(int c, int b, int e, const Bjt& p, bool exactTransitJacobian = false)
    {
        junctions[junctionCount++] = {b, e, p.polarity};
        junctions[junctionCount++] = {b, c, p.polarity};
        constexpr double vt = .02585;
        const auto vbe = p.polarity * (at(voltage, b) - at(voltage, e));
        const auto vbc = p.polarity * (at(voltage, b) - at(voltage, c));
        const auto forwardSlope = junctionSlope(vbe / vt);
        const auto reverseSlope = junctionSlope(vbc / vt);
        const auto forward = p.is * (junctionFromSlope(vbe / vt, forwardSlope) - 1);
        const auto reverse = p.is * (junctionFromSlope(vbc / vt, reverseSlope) - 1);
        const auto gf = p.is * forwardSlope / vt;
        const auto gr = p.is * reverseSlope / vt;
        const auto vce = vbe - vbc;
        const auto modulation = 1 + std::max(0., vce) / p.early;
        const auto rolloff = std::sqrt(1 + 4 * std::max(0., forward) / p.knee);
        const auto transport = 2 * forward / (1 + rolloff);
        const auto slope = gf / rolloff;
        const auto current = (transport * modulation - reverse) * p.polarity;
        const auto earlySlope = vce > 0 ? transport / p.early : 0.;
        stamp(c, b, e, current, slope * modulation);
        stamp(c, b, c, 0, -gr);
        stamp(c, c, e, 0, earlySlope);
        stamp(e, b, e, -current, -slope * modulation);
        stamp(e, b, c, 0, gr);
        stamp(e, c, e, 0, -earlySlope);
        double le = 0, ge = 0;
        if (p.leakage != 0) {
            constexpr double leakageVt = vt * 1.394;
            const double x = vbe / leakageVt;
            const double leakageSlope = junctionSlope(x);
            le = p.leakage * (junctionFromSlope(x, leakageSlope) - 1);
            ge = p.leakage * leakageSlope / leakageVt;
        }
        branch(b, e, (forward / p.beta + le) * p.polarity, gf / p.beta + ge);
        branch(b, c, reverse / p.reverseBeta * p.polarity, gr / p.reverseBeta);
        const double diffusion = gf * p.transit;
        capacitor(b, e, p.cbe + std::min(1e-9, diffusion));
        if (exactTransitJacobian && dt > 0 && diffusion > 0 && diffusion < 1e-9 && vbe > -70*vt && vbe < 36*vt) {
            const auto priorVbe = p.polarity * (at(previous, b) - at(previous, e));
            branch(b, e, 0, diffusion * (vbe - priorVbe) / (vt * dt));
        }
        capacitor(b, c, p.cbc);
    }

    bool eliminate(Vector& delta)
    {
        for (int k = 0; k < size; ++k) {
            auto pivot = k;
            for (int row = k + 1; row < size; ++row)
                if (std::abs(matrix[row][k]) > std::abs(matrix[pivot][k])) pivot = row;
            if (std::abs(matrix[pivot][k]) < 1e-16) return false;
            if (pivot != k) std::swap(matrix[pivot], matrix[k]);
            const double inverse = 1 / matrix[k][k];
            for (int row = k + 1; row < size; ++row) {
                if (matrix[row][k] == 0) continue;
                const auto scale = matrix[row][k] * inverse;
                for (int col = k + 1; col <= size; ++col) matrix[row][col] -= scale * matrix[k][col];
            }
        }
        for (int row = size - 1; row >= 0; --row) {
            auto right = matrix[row][size];
            for (int col = row + 1; col < size; ++col) right -= matrix[row][col] * delta[col];
            delta[row] = right / matrix[row][row];
            if (!std::isfinite(delta[row])) return false;
        }
        return true;
    }

    template<class Stamp>
    void solve(Stamp add, int iterations, bool predict = false, const Vector* history = nullptr)
    {
        const auto last = previous;
        const auto initial = voltage;
        previous = history ? *history : initial;
        const int warmBudget = predict && dt > 0 ? 6 : 0;
        if (warmBudget != 0) {
            for (int i = 0; i < size; ++i)
                voltage[i] += std::clamp(.8 * (voltage[i] - last[i]), -.12, .12);
        }
        for (int iteration = -warmBudget; iteration < iterations; ++iteration) {
            if (iteration == 0 && warmBudget != 0) voltage = previous;
            ++iterationsUsed;
            matrix = {};
            junctionCount = 0;
            for (int i = 0; i < size; ++i) matrix[i][i] = 1e-10;
            add();
            Vector change{};
            if (!eliminate(change)) {
                if (iteration < 0) { iteration = -1; continue; }
                break;
            }
            double maximum = 0;
            for (const auto value : change) maximum = std::max(maximum, std::abs(value));
            if (maximum < 2e-6) {
                for (int i = 0; i < size; ++i) voltage[i] += change[i];
                return;
            }
            auto damping = maximum > 4 ? 4 / maximum : 1.;
            for (unsigned k = 0; k < junctionCount; ++k) {
                const auto [a, b, sign] = junctions[k];
                const auto step = sign * ((a < 0 ? 0. : change[a]) - (b < 0 ? 0. : change[b]));
                const auto before = sign * (at(voltage, a) - at(voltage, b));
                const auto maxStep = std::max(.12, .56 - before);
                if (step > maxStep) damping = std::min(damping, maxStep / step);
            }
            for (int i = 0; i < size; ++i) voltage[i] += damping * change[i];
        }
        ++failures;
        voltage = initial;
    }
};

struct Preamp {
    enum { b1, e1, c1, e2, c2, e3, bias, count };
    Nodes<count> net;
    double inputPrior = 0, dc = 0;

    double tick(double in, double rail, double dt)
    {
        auto& n = net;
        constexpr auto g = Nodes<count>::ground, v = Nodes<count>::rail21;
        n.in = in; n.regulated = rail; n.dt = dt;
        n.solve([&] {
            n.resistor(v, c1, 47000); // R4
            n.resistor(e1, g, 330); // R5
            n.resistor(v, c2, 10000); // R6
            n.resistor(e3, e1, 10000); // R7
            n.resistor(b1, bias, 150000); // R8
            n.resistor(e2, bias, 1000); // R9
            n.resistor(bias, g, 1000); // R10
            n.resistor(e3, g, 4700); // R11
            n.resistor(e3, g, 20015); // AC loading of R12–R14
            n.capacitor(Nodes<count>::signal, b1, 2.2e-6, inputPrior); // C2
            n.transistor(c1, b1, e1, q5089);
            n.transistor(c2, c1, e2, q5089);
            n.transistor(v, c2, e3, q5089);
        }, dt == 0 ? 160 : 28);
        inputPrior = in;
        if (dt == 0) dc = n.voltage[e3];
        return n.voltage[e3] - dc;
    }

    void reset() { tick(0, 21, 0); }
};

struct OutputStage {
    enum { potTop, potWiper, b4, e4, c4, e5, c5, bias, e6, diodeTop, diodeOne,
           diodeTwo, b8, e7, e8, darlington7, darlington8, internal, out, count };
    Nodes<count> net;
    double inputPrior = 0, current = 0;

    double tick(double input, double output, double regulated, double main, double load, double dt)
    {
        auto& n = net;
        constexpr auto g = Nodes<count>::ground;
        constexpr auto v = Nodes<count>::rail21, raw = Nodes<count>::rail24;
        n.in = input; n.regulated = regulated; n.main = main; n.dt = dt;
        const auto travel = std::pow(10., (output - 15) / 20);
        // The two series sections sum to R12 + R13 + R14. End stops
        // retain a small wiper resistance to keep the matrix regular.
        const auto lower = std::max(15., 5015 * travel);
        n.solve([&] {
            n.capacitor(Nodes<count>::signal, potTop, 2.2e-6, inputPrior); // C3
            n.resistor(potTop, potWiper, 20015 - lower); // R12 + upper R13
            n.resistor(potWiper, g, lower); // lower R13 + R14
            n.capacitor(potWiper, b4, 2.2e-6); // C4
            n.capacitor(b4, g, 22e-12); // C5
            n.capacitor(bias, g, 100e-6); // C6
            n.capacitor(internal, out, 50e-6); // C7
            n.resistor(v, c4, 150000); // R15
            n.resistor(e4, g, 1000); // R16
            n.resistor(e4, internal, 15000); // R17
            n.resistor(b4, bias, 100000); // R18
            n.resistor(raw, c5, 10000); // R19
            n.resistor(e5, bias, 470); // R20
            n.resistor(bias, g, 1300); // R21
            n.resistor(e6, diodeTop, 100); // R22
            n.resistor(b8, g, 4700); // R23
            n.resistor(e7, internal, 15); // R24
            n.resistor(e8, internal, 15); // R25
            n.resistor(out, g, 22000); // R26
            n.resistor(out, g, load);
            n.transistor(c4, b4, e4, q6520);
            n.transistor(c5, c4, e5, q6512);
            n.transistor(raw, c5, e6, qA10);
            n.transistor(raw, e6, darlington7, qA13);
            n.transistor(raw, darlington7, e7, qA13);
            n.transistor(g, b8, darlington8, qA65);
            n.transistor(g, darlington8, e8, qA65);
            n.diode(diodeTop, diodeOne); // D1
            n.diode(diodeOne, diodeTwo); // D2
            n.diode(diodeTwo, b8); // D3
        }, dt == 0 ? 200 : 35);
        inputPrior = input;
        current = std::max(0., (main - n.voltage[c5]) / 10000
                               + (n.voltage[e7] - n.voltage[internal]) / 15
                               + (n.voltage[e6] - n.voltage[diodeTop]) / 100);
        return n.voltage[out];
    }

    void reset()
    {
        net.voltage = {0, 0, 1.65, .97, 2.8, 2.15, 11.4, 1.58, 10.7, 10.45,
                       9.77, 9.09, 8.41, 9.4, 9.6, 10.02, 9.05, 9.5, 0};
        tick(0, 15, 21, 24, 600, 0);
    }
};


struct CardRegulator {
    enum { diodeMid, currentBase, currentEmitter, passBase, passInternal,
           regulated, feedback, reference, count };
    Nodes<count> net;

    double tick(double rack, double load, double dt)
    {
        auto& n = net;
        constexpr auto g = Nodes<count>::ground, raw = Nodes<count>::rail24;
        n.main = rack; n.dt = dt;
        n.solve([&] {
            n.diode(raw, diodeMid); // D4
            n.diode(diodeMid, currentBase); // D5
            n.resistor(raw, currentEmitter, 82); // R56
            n.resistor(currentBase, g, 10000); // R57
            n.resistor(regulated, feedback, 6800); // R54
            n.resistor(feedback, g, 10000); // R55
            n.transistor(passBase, currentBase, currentEmitter, qA70); // Q11
            n.transistor(passBase, feedback, reference, qA10); // Q10
            n.transistor(raw, passBase, passInternal, qA13); // Q9 internal pair
            n.transistor(raw, passInternal, regulated, qA13);
            // D6, 12 V avalanche knee. Its impedance is an estimate
            // for the unspecified 400 mW zener.
            const auto x = (n.voltage[reference] - 12) / .07;
            n.branch(reference, g, .001 * Nodes<count>::junction(x),
                     .001 / .07 * Nodes<count>::junctionSlope(x));
            n.capacitor(regulated, g, 25e-6);
            n.branch(regulated, g, load, 0);
        }, dt == 0 ? 150 : 20);
        return n.voltage[regulated];
    }

    void reset()
    {
        net.voltage = {23.35, 22.7, 23.37, 22.4, 21.7, 21, 12.5, 11.95};
        tick(24, .018, 0);
    }
};


struct DetectorAmplifier {
    enum { b13, e13, c13, e14, c14, bias, e15, e16, c16,
           splitBias, b17, e17, c17, b18, e18, c18, count };
    Nodes<count> net;
    double previousInput = 0, calibration = 1, dc = 0;

    double tick(double input, double rail, double dt)
    {
        auto& n = net;
        constexpr auto g = Nodes<count>::ground, v = Nodes<count>::rail21;
        n.in = input; n.regulated = rail; n.dt = dt;
        n.solve([&] {
            n.capacitor(Nodes<count>::signal, b13, 2.2e-6, previousInput); // C9
            n.resistor(v, c13, 150000); // R29
            n.resistor(e13, g, 1000); // R30
            n.resistor(v, c14, 15000); // R31
            n.resistor(e14, bias, 470); // R32
            n.resistor(b13, bias, 100000); // R33
            n.resistor(bias, g, 1000); // R34
            n.capacitor(bias, g, 100e-6); // C10
            n.resistor(e15, g, 1300); // R35
            n.resistor(v, c16, 3900); // R36
            n.resistor(e13, e16, 22000); // R37
            n.resistor(e16, g, 4700); // R38
            n.resistor(v, splitBias, 47000); // R39
            n.resistor(splitBias, g, 4700); // R40
            n.resistor(splitBias, b17, 33000); // R41
            n.resistor(splitBias, b18, 33000); // R42
            n.resistor(v, c17, 4700); // R43
            n.resistor(e17, g, 820); // R44
            n.resistor(v, c18, 4700); // R45
            n.resistor(e18, g, 820); // R46
            n.capacitor(c16, b17, 2.2e-6); // C11
            n.capacitor(e16, b18, 2.2e-6); // C12
            n.transistor(c13, b13, e13, q6520);
            n.transistor(c14, c13, e14, q6512);
            n.transistor(v, c14, e15, qA10);
            n.transistor(c16, c14, e16, qA10);
            n.transistor(c17, b17, e17, qA10);
            n.transistor(c18, b18, e18, qA10);
        }, dt == 0 ? 160 : 24);
        previousInput = input;
        return n.voltage[c17] - n.voltage[c18];
    }

    void reset()
    {
        net.voltage = {1.2, .56, 3.6, 2.95, 10.7, 2.25, 10.05, 10.05,
                       12, 1.9, 1.65, 1, 15, 1.65, 1, 15};
        dc = tick(0, 21, 0);
        const auto quiet = net;
        constexpr double tau = 6.283185307179586, rate = 48000;
        double sine = 0, cosine = 0;
        for (int i = 0; i < 960; ++i) {
            const auto phase = tau * i / 48;
            const auto value = tick(.003 * std::sin(phase), 21, 1 / rate) - dc;
            if (i < 480) continue;
            sine += value * std::sin(phase);
            cosine += value * std::cos(phase);
        }
        calibration = 240 / std::max(.01, std::hypot(sine, cosine));
        net = quiet;
        previousInput = 0;
    }
};

}
