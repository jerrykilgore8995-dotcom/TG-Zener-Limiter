#pragma once
// TG-style reduced audio DSP. C++17, real-time processing, no nodal solver.
// This is a MEASURED-SINGLE-TONE SURROGATE, not a general SPICE equivalent.
// Harmonic phasors read from the normalized four-frequency circuit lattice.
// Copyright: new implementation provided to the user; no third-party framework required.
#include "TGReferenceGrid.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <string>

namespace tgfast {
constexpr double PI=3.14159265358979323846264338327950288;
inline double clip(double v,double a,double b) noexcept{return std::max(a,std::min(b,v));}
inline double amp(double db) noexcept{return std::pow(10.,db/20.);}
inline double db(double a) noexcept{return 20.*std::log10(std::max(1e-15,a));}
inline double wrap(double x) noexcept {while(x>PI)x-=2*PI;while(x<-PI)x+=2*PI;return x;}
inline double grLaw(double inputDB,double thresholdDB,bool soft) noexcept {
    const double x=inputDB-thresholdDB, slope=0.875;
    if(!soft)return slope*std::max(0.,x);
    if(x<=-1.5)return 0.;if(x>=1.5)return slope*x;
    return slope*(x+1.5)*(x+1.5)/6.; // 3 dB knee
}
// Input 0..100% = -18..+18 dB, fixed original +14dB stage AFTER input.
inline double inputDb(int pct) noexcept{return -18.+0.36*clip(double(pct),0.,100.);}
inline double outputDb(int pct) noexcept{return -24.+0.48*clip(double(pct),0.,100.);}
struct Controls{
    int inputPct=50;    // user 1% steps
    int outputPct=50;   // -24..+24dB clean digital make-up
    int recovery=1;     // 50,100,250,500,1000,2000 ms
    bool softKnee=false;// false=0dB true=3dB
    double thresholdDb=-8.857143; // DAW dBFS, calibrated threshold is a design parameter
    bool nonlinear=true;
};
inline constexpr std::array<double,6> recoveries{50.,100.,250.,500.,1000.,2000.};

// Constant-memory monotonic queue; no dynamically allocated audio-thread storage.
class CrestHold{
    struct Node{double v=0.;uint64_t time=0;};
    std::array<Node,8192> nodes_{};
    uint64_t t_=0, head_=0,tail_=0,window_=573;
public:
    void prepare(double fs){window_=static_cast<uint64_t>(std::ceil(fs*0.013));
        if(window_>8191) throw std::invalid_argument("13ms hold requires larger ring for fs>630kHz"); reset();}
    void reset() noexcept{t_=head_=tail_=0;}
    double process(double x) noexcept {
        uint64_t n=t_++;
        while(head_!=tail_ && nodes_[head_&8191].time+window_<=n)++head_;
        while(head_!=tail_ && nodes_[(tail_-1)&8191].v<=x)--tail_;
        nodes_[tail_&8191]={x,n};++tail_;
        return nodes_[head_&8191].v;
    }
};

// A low-cost dominant-sinusoid tracker: linear prediction on 3 consecutive samples.
// Exact for settled noiseless sinusoids; a program mix is NOT a single sinusoid.
// Its instantaneous envelope estimates MUST NOT be interpreted as literal harmonic
// fitting on arbitrary music. A full wideband nonlinear system needs more kernels.
class DominantTone{
    double old1_=0.,old2_=0., num_=0.,den_=0.,coef_=0.995;
    double hz_=1000.,fs_=44100., envelope_=0.;
    double refHz_=0.,fixedCos_=1.,fixedSin_=0.;bool fixed_=false;
public:
    void prepare(double fs){fs_=fs;coef_=std::exp(-1./(0.02*fs_));reset();}
    void reset(){old1_=old2_=0;num_=den_=envelope_=0;hz_=1000.;}
    // Validation-only fixed frequency eliminates tracking uncertainty from
    // tests of nonlinear harmonic reconstruction. Does not synthesize tones.
    void fixedFrequencyForValidation(double f){fixed_=f>0.;refHz_=f;
        fixedCos_=std::cos(2*PI*f/fs_);fixedSin_=std::sin(2*PI*f/fs_);}

    struct Result{double phase=0.;double amplitude=0.;double hz=1000.;};
    Result process(double x){
        double f=refHz_;
        if(!fixed_){
            const double a=old1_*(x+old2_)*0.5,b=old1_*old1_;
            num_=coef_*num_+(1.-coef_)*a;
            den_=coef_*den_+(1.-coef_)*b;
            const double c=clip(num_/std::max(den_,1e-16),-0.999999,0.999999);
            const double autoHz=clip(fs_*std::acos(c)/(2*PI),40.,std::min(18000.,fs_*0.42));
            hz_+=0.001*(autoHz-hz_);
            f=hz_;
        }
        // cos(phi) = (x*cos(w)-x[n-1]) / sin(w), for x=A*sin(phi).
        const double cw=fixed_?fixedCos_:std::cos(2*PI*f/fs_);
        const double sw=fixed_?fixedSin_:std::sin(2*PI*f/fs_);
        const double cs=(x*cw-old1_)/std::max(1e-9,sw);
        const double magnitude=std::hypot(x,cs);
        // Small envelope release smooths transient gain/phase instability.
        envelope_+=((magnitude>envelope_)?0.1:0.01)*(magnitude-envelope_);
        old2_=old1_;old1_=x;
        return {std::atan2(x,cs),magnitude,f};
    }
};

class TGFastZenerLimiter {
public:
    // Caller loads the measured normalized lattice OFF the audio callback.
    // Can be embedded into a VST3 resource by replacing path load with memory load.
    void loadReference(const std::string& path){ref_.load(path);loaded_=true;}
    void prepare(double sampleRate) {
        if(!loaded_)throw std::logic_error("loadReference before prepare");
        fs_=clip(sampleRate,8000.,500000.);hold_.prepare(fs_);tone_.prepare(fs_);
        attack_=std::exp(-1./(fs_*0.008));
        gainSmooth_=1.-std::exp(-1./(fs_*0.005)); // 5ms digital knob smoothing
        updateControls();reset();
    }
    void reset() noexcept {hold_.reset();tone_.reset();env_=currentGR_=0.;
        inGain_=targetInGain_;outGain_=targetOutGain_;
        samples_=0; for(auto &c:coefs_)c={};}
    void setControls(Controls c) noexcept {c.inputPct=std::clamp(c.inputPct,0,100);
        c.outputPct=std::clamp(c.outputPct,0,100); c.recovery=std::clamp(c.recovery,0,5);
        c.thresholdDb=clip(c.thresholdDb,-90.,12.);c_=c;updateControls();}
    void setReferenceToneForValidation(double hz){tone_.fixedFrequencyForValidation(hz);}
    // Validation only: interpolate original circuit bias at requested index;
    // normal operation chooses measured bias from the GR->attenuation map.
    void setReferenceBiasForValidation(int index){testBias_=(index>=0&&index<17)?index:-1;}
    // Validation only: jump detector to the known steady peak for an isolated
    // sine reference. This is not a process option exposed to the plugin user.
    void primeSteadyDetectorForValidation(double peakDaw)noexcept {env_=std::abs(peakDaw);}
    double currentGR()const noexcept{return currentGR_;}
    double meterFraction()const noexcept{return clip(currentGR_/20.,0.,1.);}
    double overRangeDb()const noexcept{return std::max(0.,currentGR_-20.);}
    bool meterRed()const noexcept{return currentGR_>20.;}
    double currentBias()const noexcept{return biasV_;}
    // Process MONO. Stereo: instantiate one per channel or share detector externally.
    // All arrays are fixed-size; interpolations occur every 32 samples.
    double process(double input) noexcept {
        // Digital input control -> fixed +14dB stage. Character only in cell.
        inGain_+=(targetInGain_-inGain_)*gainSmooth_;
        outGain_+=(targetOutGain_-outGain_)*gainSmooth_;
        const double pre=input*inGain_;
        // Detector monitors the driven signal AFTER the fixed +14dB digital gain.
        const double held=hold_.process(std::abs(pre));
        const double alpha=held>env_?attack_:release_;
        env_=alpha*env_+(1.-alpha)*held;
        currentGR_=grLaw(db(env_),c_.thresholdDb,c_.softKnee);
        const double gain=amp(-currentGR_);
        // Mapping from full-scale amplitude to archived solver volts:
        // at input -18 dBFS, 100% knob and +14dB, peak = 0.39716V.
        const double physical=pre*0.07943282347242815;
        const auto tr=tone_.process(physical);
        const double level=tr.amplitude;
        const double sourceAmplitude=std::abs(physical);
        (void)sourceAmplitude;
        const double percent=double(c_.inputPct);
        // Bias is selected by matching the 1kHz reference cell attenuation to
        // requested GR, clamped to original characterized bias range.
        if((samples_++ & 31u)==0u){
            const double mappedBias=testBias_>=0?ref_.biasAt(testBias_):biasForGR(currentGR_,c_.inputPct);
            // no extra digital GR is introduced by selecting the bias; GR is the
            // already computed 8:1 attenuation applied exactly once below.
            biasV_=mappedBias;
            updateHarmonics(percent,biasV_,tr.hz);
        }
        // Synthesize complex measured phasors as sinusoid harmonics.
        // For an input sine with phase theta, K_n C_n measured by
        // 2/N sum(y * exp(-j*n*theta)); y_n=|C_n|*sin(n*theta+arg(C_n)+pi/2).
        // Magnitudes here are normalized to K1 by measured grid.
        double fundamental=0., residual=0.;
        const double theta=tr.phase;
        // Re(z^n * C_n) via complex recurrence: 2 trig calls per sample,
        // rather than 40 trigonometric calls. No solver in the callback.
        const double c0=std::cos(theta),s0=std::sin(theta);
        double zr=c0,zi=s0;
        for(int h=0;h<20;++h){
            if(double(h+1)*tr.hz<=fs_*0.49){ // reject out-of-band harmonics
                const auto &c=coefs_[h];
                const double v=c.re*zr-c.im*zi;
                if(h==0)fundamental=v;else residual+=v;
            }
            const double nextR=zr*c0-zi*s0, nextI=zr*s0+zi*c0;
            zr=nextR; zi=nextI;
        }
        // Fitted normalized frequency response; absolute output uses input in
        // DAW units with GR exact. The 1kHz K1 ratio forms unity reference.
        const double post=(fundamental+(c_.nonlinear?residual:0.))*level*gain*color_;
        return post * outGain_ / 0.07943282347242815; // undo volts->DAW scale
    }
private:
    tgref::ReferenceGrid ref_{};bool loaded_=false;
    Controls c_{};CrestHold hold_{};DominantTone tone_{};
    double fs_=44100.,attack_=0.,release_=0.,gainSmooth_=1.;
    double inGain_=1.,outGain_=1.,targetInGain_=1.,targetOutGain_=1.;
    double env_=0.,currentGR_=0.,biasV_=-18.68,color_=1.;
    int testBias_=-1;uint64_t samples_=0;
    std::array<tgref::Phasor,20> coefs_{};
    void updateControls()noexcept {targetInGain_=amp(inputDb(c_.inputPct)+14.);
        targetOutGain_=amp(outputDb(c_.outputPct));
        release_=std::exp(-1./(fs_*recoveries[c_.recovery]*.001));}
    double biasForGR(double targetGR,int p)const noexcept {
        const int pct=std::clamp(p,0,100);
        // The cell's measured GR may top out below 20 dB in the 17 bias points.
        // Do NOT pretend that its bias produces the sidechain's entire 20 dB.
        const double maxR=ref_.k1GainReduction(1,pct,16);
        if(targetGR<=0)return ref_.biasAt(0);
        if(targetGR>=maxR)return ref_.biasAt(16);
        for(int i=1;i<17;++i){const double r=ref_.k1GainReduction(1,pct,i);
            if(targetGR<=r){const double lower=ref_.k1GainReduction(1,pct,i-1);
                double a=clip((targetGR-lower)/std::max(1e-10,r-lower),0.,1.);
                return ref_.biasAt(i-1)*(1-a)+ref_.biasAt(i)*a;}}
        return ref_.biasAt(16);
    }
    void updateHarmonics(double pct,double bias,double hz) noexcept {
        const double h1=std::hypot(ref_.lookup(pct,bias,hz,1).re,ref_.lookup(pct,bias,hz,1).im);
        for(int i=0;i<20;++i){const auto x=ref_.lookup(pct,bias,hz,i+1);
            coefs_[i]={x.re/std::max(1e-14,h1),x.im/std::max(1e-14,h1)};}
        // Complex interpolation between calibrated conditions can slightly lower
        // THD due to phasor cancellation. Reinstate requested 0.02% per 1%
        // at ANY interpolated bias or log-frequency without changing relative
        // harmonic balance or each coefficient phase.
        double sq=0.;for(int i=1;i<20;++i)
            sq+=coefs_[i].re*coefs_[i].re+coefs_[i].im*coefs_[i].im;
        const double desired=.0002*pct;
        const double scale=(sq>1e-26)?(desired/std::sqrt(sq)):0.;
        for(int i=1;i<20;++i){coefs_[i].re*=scale;coefs_[i].im*=scale;}
        const double g1=std::hypot(ref_.lookup(pct,bias,1000.,1).re,ref_.lookup(pct,bias,1000.,1).im);
        color_=h1/std::max(1e-14,g1);
    }
};
} // namespace tgfast
