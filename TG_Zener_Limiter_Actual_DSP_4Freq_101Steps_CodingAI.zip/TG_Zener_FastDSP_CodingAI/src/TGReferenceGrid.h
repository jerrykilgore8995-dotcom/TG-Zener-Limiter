#pragma once
// TG1 v1.3 archived nodal circuit: steady-sinusoid harmonic reference reader.
// This is deliberately NOT a real-time gain-cell replacement. It is a fast,
// exact-at-grid calibration oracle for a separate physically plausible DSP model.
// Read the supplied docs before building a VST3 from it.
#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstdint>
#include <fstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>

namespace tgref {
struct Phasor { double re=0, im=0; };
class ReferenceGrid {
 public:
  static constexpr int F=4,B=17,P=101,H=20;
  ReferenceGrid()=default;
  explicit ReferenceGrid(const std::string& path){load(path);}
  void load(const std::string& path) {
    std::ifstream f(path,std::ios::binary); if(!f) throw std::runtime_error("cannot open TG reference file");
    char magic[8]; f.read(magic,8);
    if(std::string(magic,8)!="TGZ4FR01")throw std::runtime_error("wrong TG reference magic");
    std::array<uint32_t,4> dims{};f.read(reinterpret_cast<char*>(dims.data()),sizeof(dims));
    if(dims!=std::array<uint32_t,4>{F,B,P,H})throw std::runtime_error("wrong TG reference dimensions");
    f.read(reinterpret_cast<char*>(freq.data()),sizeof(freq));
    f.read(reinterpret_cast<char*>(bias.data()),sizeof(bias));
    f.read(reinterpret_cast<char*>(inputDb.data()),sizeof(inputDb));
    dc.assign(F*B*P,0.0);data.assign(F*B*P*H,{});
    for(int fi=0;fi<F;++fi)for(int bi=0;bi<B;++bi)for(int pi=0;pi<P;++pi){
      auto index=(fi*B+bi)*P+pi;
      f.read(reinterpret_cast<char*>(&dc[index]),sizeof(double));
      f.read(reinterpret_cast<char*>(&data[index*H]),H*sizeof(Phasor));
    }
    if(!f)throw std::runtime_error("truncated TG reference file");
    ready=true;
  }
  // Exact values at integer frequency index, control-bias index, input percent and harmonic.
  Phasor atIndex(int fi,int bi,int pct,int harmonic)const{
    require();if(fi<0||fi>=F||bi<0||bi>=B||pct<0||pct>=P||harmonic<1||harmonic>H)
      throw std::out_of_range("TG reference index");
    return data[(((fi*B+bi)*P+pct)*H)+(harmonic-1)];
  }
  // Smoothly queries the calibrated K1..K20 sinusoidal reference surface.
  // NOT an audio signal processor. Complex interpolation can underestimate
  // magnitudes across large phase rotations; use only as an interpolation guide.
  Phasor lookup(double inputPct,double biasV,double hz,int harmonic) const {
    require(); if(harmonic<1||harmonic>H)throw std::out_of_range("harmonic");
    inputPct=std::clamp(inputPct,0.,100.);
    biasV=std::clamp(biasV,bias.front(),bias.back());
    hz=std::clamp(hz,freq.front(),freq.back());
    auto [loF,hiF,wF]=bracketLog(freq,hz);
    auto [loB,hiB,wB]=bracketLinear(bias,biasV);
    int loP=std::min(P-1,int(inputPct)), hiP=std::min(P-1,loP+1);
    double wP=(hiP==loP?0:inputPct-loP);
    auto v=[&](int f,int b,int p){return atIndex(f,b,p,harmonic);};
    auto lerp=[](Phasor a,Phasor b,double t){return Phasor{a.re+(b.re-a.re)*t,a.im+(b.im-a.im)*t};};
    auto alongInput=[&](int f,int b){return lerp(v(f,b,loP),v(f,b,hiP),wP);};
    auto alongBias=[&](int f){return lerp(alongInput(f,loB),alongInput(f,hiB),wB);};
    return lerp(alongBias(loF),alongBias(hiF),wF);
  }
  double biasAt(int i)const{require();return bias.at(i);}
  double frequencyAt(int i)const{require();return freq.at(i);}
  double inputDbAt(int i)const{require();return inputDb.at(i);}
  double dcAt(int fi,int bi,int pct)const{require();return dc.at((fi*B+bi)*P+pct);}
  double k1GainReduction(int fi,int pct,int bi)const{
    const auto noReduction=atIndex(fi,0,pct,1), compressed=atIndex(fi,bi,pct,1);
    const auto m0=std::hypot(noReduction.re,noReduction.im),m=std::hypot(compressed.re,compressed.im);
    return 20.0*std::log10(std::max(1e-30,m0)/std::max(1e-30,m));
  }
 private:
  bool ready=false;
  std::array<double,F> freq{};
  std::array<double,B> bias{};
  std::array<double,P> inputDb{};
  std::vector<double> dc;
  std::vector<Phasor> data;
  void require()const{if(!ready)throw std::runtime_error("TG reference not loaded");}
  template<size_t N> static std::tuple<int,int,double> bracketLinear(const std::array<double,N>& a,double x){
    int hi=int(std::upper_bound(a.begin(),a.end(),x)-a.begin());
    if(hi<=0)return {0,0,0.0};if(hi>=int(N))return {int(N)-1,int(N)-1,0.0};
    int lo=hi-1;return {lo,hi,(x-a[lo])/(a[hi]-a[lo])};
  }
  template<size_t N> static std::tuple<int,int,double> bracketLog(const std::array<double,N>& a,double x){
    auto [lo,hi,w]=bracketLinear(a,x);
    if(lo==hi)return {lo,hi,0.0};
    return {lo,hi,(std::log(x)-std::log(a[lo]))/(std::log(a[hi])-std::log(a[lo]))};
  }
};
} // namespace tgref
