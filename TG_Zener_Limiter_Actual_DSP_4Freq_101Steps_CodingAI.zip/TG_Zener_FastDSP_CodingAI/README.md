# TG-Style Fast Zener Gain-Cell DSP — IMPLEMENTED C++17 Handoff

**This contains actual compilable real-time audio DSP and independently rendered numerical tests. It is NOT another instructions-only package.**

## What is implemented

`INPUT digital gain (-18..+18 dB, 0..100% in 1% steps)` → `fixed +14 dB digital pre-gain` → `calibrated frequency-dependent nonlinear gain cell, with 8:1 sidechain control` → `OUTPUT digital gain (-24..+24 dB, 0..100% in 1% steps)`.

- The lightweight **real-time gain cell does not contain a nodal/SPICE/Newton solver**. C++ source in `src/TGFastZenerLimiter.h`.
- Harmonic generation uses the original *archived nodal cell*'s **complex K1–K20** spectra at **100 Hz, 1 kHz, 5 kHz, 10 kHz**, all **101 integer input positions**, and **17 control-bias points**, from `reference/TGZener4Freq_THD2pct_InputScaled.bin`. It interpolates frequency logarithmically and bias/input continuously. It reconstructs time-domain harmonics using a lightweight dominant-tone phase estimate and recursive complex powers, not invented coefficients.
- THD = **0.02 × input percentage** in percent: 0%=0%, 25%=0.5%, 50%=1%, 100%=2% at all four measured frequencies **when measured at reference sample rates sufficient for K20**. The harmonic ratios and relative phase are preserved from the original circuit data, but harmonic amplitudes were intentionally normalized to this user-requested THD law. **This is not original unmodified solver distortion.**
- The **K1 frequency-response magnitude and phase** are retained relative to 1kHz as measured in the target grid. K2..K20 preserve the measured relative phase. No modeled analog input or output transformer/PSU, in accordance with request.
- Limiter **8:1** above threshold; **0 dB hard / 3 dB soft knee**; **8 ms detector time constant**; selectable **50/100/250/500/1000/2000 ms release**; **13 ms sidechain-only sliding crest hold**. No intentionally introduced sidechain-to-audio modulation. Detector does not filter audio samples.
- 20dB GR near maximum input for a **-18dBFS peak** sine with default threshold `-8.857143 dBFS` in the *post-input-drive* detector domain. Other source levels legitimately yield different GR. Meter is actual commanded reduction, 0..20 display plus red overrange. No hard GR ceiling.
- Controls use 5ms ramps to avoid zipper noise. Post-cell OUTPUT gain never changes harmonic ratios unless downstream clipping occurs.

## Verified numerical results

`results/full_6868_rendered_complex_validation.csv`: **6,868 independent time-domain steady-sine renders** across all 4 frequencies × 101 input percentages × 17 bias positions, with comparison of each K2–K20 relative complex phasor versus measured normalized target.

- Max absolute K2–K20 magnitude deviation (for harmonics above -140 dBc): **0.000023 dB**.
- Max absolute relative harmonic phase deviation: **0.000140 degrees**.
- Max absolute K2–K20 THD percentage-point deviation: **0.00000000019 percentage points** (1.85e-10).
- Output K1 phase deviation at measured anchors: below **0.000000001 degrees** after steady-state settling.
- These precise numbers apply to **calibration sinusoids with measured frequency provided to the tracker via the validation-only method**, at the original measurement sample rates (44.1kHz at 100Hz/1kHz, 220.5kHz at 5kHz, 441kHz at 10kHz). Do not extrapolate that precision to unrestricted audio, 44.1kHz Nyquist-limited high-frequency harmonics, or hardware.
- `results/rendered_sine_validation.csv`: an additional 84 independent 0.3-second-settle test renders. No nodal solver in the processed signal path.
- `tests/test_detector_clean.cpp`: 40–200Hz detector-ripple isolation. Nonlinear model disabled, K3 < -166dBc in 40–200Hz tested 100% input; 100Hz K3 below ~-279dBc numerical floor, not a physical noise measurement.
- `tests/test_controls.cpp`: all six release control selections, 8:1 static law, 20dB calibrated GR, red overrange at +6dB stronger input.
- `tests/test_program.cpp`: 12 seconds synthetic chord+transient sound, no NaN/Inf, runtime bench. Beware transient output peaks may exceed full-scale due to +14dB pre-gain and 8ms attack; no safety clipping is inserted.

## CRITICAL limits before a release-quality VST3

1. The exact K2–K20 and K1 matches are **steady-state SINGLE-TONE matches**. The low-cost dominant-tone estimator DOES process arbitrary program audio but its harmonic model is not validated against a zener circuit for chords, intermodulation, bursts, multi-tone phase, or rapidly varying spectra. The tone tracker uses a dominant-frequency approximation. This is functional audio DSP, **not a proven fully SPICE-equivalent model of every waveform**. Production follow-up: fit and test a causal multiband nonlinear/Volterra/state-space surrogate against transient and two-tone circuit renders. Do not represent perfect single-tone calibration as universal circuit equivalence.
2. The sidechain is **user-requested simplified digital 8:1 + 13ms hold**, not a component-level EMI detector simulation. The 8ms is the smoothing **time constant**, not 8ms to 90% GR. The 13ms hold delays the start of release. Verify audible timing in host before declaring equivalence.
3. Harmonics above Nyquist **must not alias**. The code suppresses harmonic orders outside Nyquist. Consequently, a 10kHz source in a 44.1kHz host cannot exhibit the whole K2–K20 2% reference THD because K3–K20 are physically unrepresentable. For production, add oversampling + quality anti-aliasing with correct latency compensation and evaluate only in-band residuals at output rate. Bare harmonic rejection is only a first anti-alias precaution.
4. The original 18-node circuit solver was **NOT proven equivalent to actual EMI or Chandler hardware**. The raw solver has estimated device parameters, no explicit isolated-cell 10kOhm output termination, and the 10kOhm legacy CSV is from an **older FULL plugin chain**, not from this isolated cell. Keep those sources separate.
5. The input-to-circuit reference calibration is **0.07943282347242815 internal reference volts per digital full-scale** after +14dB. This maps a -18dBFS sine at input=100% into the original solver's ~0.397V peak measurement condition. The digital output controls do not reproduce EMI analog output stages.
6. The phase-reference fit is constructed from a no-delay dominant-tone estimator. As a potentially nonphysical input-dependent nonlinear reconstruction, validate signal causality, envelope behavior, and IMD for real music. Audio code has no declared plugin latency but may generate artifacts on nonstationary/polyphonic signals. Numerical CPU tests are not Windows DAW benchmarks.

## Build, run, and connect to coding AI

Requires C++17 compiler (GCC/Clang/MSVC) and standard library. No JUCE or Windows plugin SDK is needed for the DSP library. The reference file MUST be loaded **off audio callback** before `prepare()`, e.g. in plugin initialization (ideally embed binary as a resource instead of filesystem dependency). All processing allocations occur outside callback.

```bash
cd TG_Zener_FastDSP_CodingAI
bash tools/build_and_test.sh
```

Minimal integration:

```cpp
#include "src/TGFastZenerLimiter.h"
tgfast::TGFastZenerLimiter effect;
effect.loadReference("reference/TGZener4Freq_THD2pct_InputScaled.bin");
effect.prepare(44100.0);
tgfast::Controls ctl;
ctl.inputPct=100;  // 0..100 in 1% steps
ctl.outputPct=50;  // 0dB makeup
ctl.recovery=1;    // 100ms
ctl.softKnee=false;
effect.setControls(ctl);
float output=static_cast<float>(effect.process(inputSample));
double gr=effect.currentGR();
```

For stereo channels instantiate one per channel (dual mono); *linked* detection requires a shared detector extension by the coding AI. `setReferenceToneForValidation` and `setReferenceBiasForValidation` and `primeSteadyDetectorForValidation` are ONLY for calibration tests; never expose them as plugin controls.

See `docs/CODING_AI_HANDOFF.md` and `docs/PROVENANCE_AND_MEASUREMENT.md`.
