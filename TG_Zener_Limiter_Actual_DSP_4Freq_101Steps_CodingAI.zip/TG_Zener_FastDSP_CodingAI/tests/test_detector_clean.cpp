#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <complex>
#include <cstdio>
using namespace tgfast;
int main(int argc,char**argv){if(argc<2)return 2;
 for(double f:{40.,50.,60.,100.,200.})for(bool fixed:{false,true}){
  TGFastZenerLimiter dsp;dsp.loadReference(argv[1]);dsp.prepare(44100);
  Controls c;c.inputPct=100;c.nonlinear=false;c.thresholdDb=-8.857143;dsp.setControls(c);
  if(fixed)dsp.setReferenceToneForValidation(f);
  double real[5]{},imag[5]{};const int settle=88200,N=44100;
  for(int i=0;i<N+settle;++i){double y=dsp.process(amp(-18.)*sin(2*PI*f*i/44100.));
   if(i>=settle)for(int n=1;n<=5;n+=2){const double a=2*PI*n*f*i/44100.;real[n-1]+=y*cos(a);imag[n-1]-=y*sin(a);}}
  const double k1=hypot(real[0],imag[0]);
  printf("%.0f Hz %s: K3 %.2f dBc K5 %.2f dBc GR %.3f dB\n",f,fixed?"fixed":"auto",20*log10(std::max(1e-30,hypot(real[2],imag[2]))/k1),20*log10(std::max(1e-30,hypot(real[4],imag[4]))/k1),dsp.currentGR());
 }
}
