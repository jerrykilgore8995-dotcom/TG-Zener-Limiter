#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <cstdio>
#include <stdexcept>
using namespace tgfast;
int main(int argc,char**argv){
 if(argc<2)return 2;
 TGFastZenerLimiter c;c.loadReference(argv[1]); c.prepare(44100.);
 Controls settings; settings.inputPct=100; settings.outputPct=50; settings.thresholdDb=-25.;c.setControls(settings);
 double rms=0;
 for(int i=0;i<44100;++i){double x=amp(-18.)*sin(2*PI*100*i/44100.);
    double y=c.process(x);if(!std::isfinite(y))throw std::runtime_error("NaN output");rms+=y*y;}
 printf("rms=%.8f gr=%.4f dB overrange=%.4f dB\n",std::sqrt(rms/44100),c.currentGR(),c.overRangeDb());
 if(!(c.currentGR()>=0))return 1;
 if(std::abs(grLaw(0,-10,false)-8.75)>1e-8)return 1;
 if(std::abs(grLaw(0,-10,true)-8.75)>1e-8)return 1;
 return 0;
}
