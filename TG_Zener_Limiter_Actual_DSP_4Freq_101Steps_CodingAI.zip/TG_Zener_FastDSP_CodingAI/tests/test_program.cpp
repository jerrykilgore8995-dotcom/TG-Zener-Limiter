#include "../src/TGFastZenerLimiter.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <stdexcept>
using namespace tgfast;
int main(int argc,char**argv){if(argc<2)return 2;
 TGFastZenerLimiter d;d.loadReference(argv[1]);d.prepare(44100);
 Controls c;c.inputPct=75;c.outputPct=50;c.thresholdDb=-8.857143;d.setControls(c);
 const int N=44100*12;
 double peak=0, rms=0;
 auto start=std::chrono::steady_clock::now();
 for(int i=0;i<N;++i){
  double t=double(i)/44100.;
  double x=.11*sin(2*PI*100*t)+.06*sin(2*PI*1000*t)+.04*sin(2*PI*1537*t);
  if(i%5512==0)x+=.75; // occasional transient
  if(i==N/2){c.inputPct=50;d.setControls(c);}
  double y=d.process(x);
  if(!std::isfinite(y))throw std::runtime_error("NaN/Inf on polyphonic program input");
  rms+=y*y;peak=std::max(peak,std::abs(y));
 }
 auto end=std::chrono::steady_clock::now();
 double seconds=std::chrono::duration<double>(end-start).count();
 printf("12s chord+transient render; CPU seconds %.4f, real-time fraction %.3f, peak %.6f, rms %.6f, GR %.3f dB\n",seconds,seconds/12.,peak,std::sqrt(rms/N),d.currentGR());
 return 0;
}
