#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace tgfast;
int main(int argc,char**argv){
 if(argc<2)return 2;
 const char* name=argv[1];
 tgref::ReferenceGrid reference(name);
 printf("freq_hz,input_pct,bias_index,sample_rate,thd_pct,target_thd_pct,thd_error_pp,k1_amp,k1_phase_deg,k2_dbc,k3_dbc,k4_dbc,k5_dbc,k6_dbc,sidechain_gr_db,max_harm_magnitude_error_db,max_harm_relative_phase_error_deg,k1_phase_error_deg\n");
 for(int fIdx=0;fIdx<4;++fIdx){
  const double frequency[]={100,1000,5000,10000};
  const double srate[]={44100,44100,220500,441000};
  const int pctList[]={0,1,10,25,50,75,100};
  const int biasList[]={0,8,16};
  for(int pct:pctList)for(int bias:biasList){
   TGFastZenerLimiter dsp; dsp.loadReference(name);dsp.prepare(srate[fIdx]);
   dsp.setReferenceToneForValidation(frequency[fIdx]); dsp.setReferenceBiasForValidation(bias);
   Controls c;c.inputPct=pct;c.thresholdDb=-8.857143;dsp.setControls(c);
   // Reference signal is -18dBFS sine.
   // settled at 0.3s; capture 10 cycles at 100Hz, 100 at 1k, etc.
   const int settle=static_cast<int>(srate[fIdx]*0.30);
   const int ns=static_cast<int>(srate[fIdx]*0.1); // coherent at all freqs
   std::vector<double> y(ns);
   for(int i=0;i<settle+ns;++i){
      const double x=amp(-18)*std::sin(2*PI*frequency[fIdx]*double(i)/srate[fIdx]);
      const double z=dsp.process(x);
      if(i>=settle)y[i-settle]=z;
   }
   std::complex<double> coeff[20]{};
   for(int h=1;h<=20;++h){
      for(int i=0;i<ns;++i){
         const double a=2*PI*frequency[fIdx]*double(h)*double(i+settle)/srate[fIdx];
         coeff[h-1]+=y[i]*std::complex<double>(std::cos(a),-std::sin(a));
      }
      coeff[h-1]*=2.0/ns;
   }
   double k1=std::abs(coeff[0]),powr=0;
   for(int h=2;h<=20;++h)powr+=std::norm(coeff[h-1]);
   const double thd=100*std::sqrt(powr)/std::max(1e-15,k1);
   printf("%.0f,%d,%d,%.0f,%.9g,%.9g,%+.9g,%.9g,%.4f",frequency[fIdx],pct,bias,srate[fIdx],thd,0.02*pct,thd-.02*pct,k1,std::arg(coeff[0])*180/PI);
   for(int h=2;h<=6;++h)printf(",%.3f",20*std::log10(std::max(1e-15,std::abs(coeff[h-1]))/std::max(k1,1e-15)));
   // Complex relative spectra: compare every harmonic K2..K20 (not just THD).
   const auto target1=reference.atIndex(fIdx,bias,pct,1);
   const std::complex<double> k1ref(target1.re,target1.im);
   double maxAmpError=0,maxPhaseError=0;
   for(int h=2;h<=20;++h){
       const auto tar=reference.atIndex(fIdx,bias,pct,h);
       const std::complex<double> kref(tar.re,tar.im);
       if(std::abs(kref)/std::max(1e-30,std::abs(k1ref))<1e-7)continue; // below -140 dBc
       const auto targetRatio=kref/k1ref;
       const auto actualRatio=coeff[h-1]/coeff[0];
       const double measuredMag=20*std::log10(std::max(1e-30,std::abs(actualRatio)));
       const double targetMag=20*std::log10(std::max(1e-30,std::abs(targetRatio)));
       maxAmpError=std::max(maxAmpError,std::abs(measuredMag-targetMag));
       const double dphase=std::arg(actualRatio/targetRatio)*180/PI;
       maxPhaseError=std::max(maxPhaseError,std::abs(dphase));
   }
   const double k1phaseerror=std::arg(coeff[0]/k1ref)*180/PI;
   printf(",%.5f,%.9g,%.9g,%.9g\n",dsp.currentGR(),maxAmpError,maxPhaseError,k1phaseerror);
  }
 }
}
