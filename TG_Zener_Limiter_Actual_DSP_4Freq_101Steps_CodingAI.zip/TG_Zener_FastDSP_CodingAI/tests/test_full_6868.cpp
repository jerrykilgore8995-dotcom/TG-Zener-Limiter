#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <complex>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
using namespace tgfast;
int main(int argc,char**argv){
 if(argc<2)return 2;
 const double frequencies[]={100,1000,5000,10000};
 const double rates[]={44100,44100,220500,441000};
 tgref::ReferenceGrid ref(argv[1]);
 std::puts("frequency,input_pct,bias_index,rendered_thd_pct,target_thd_pct,thd_error_pp,max_magnitude_error_db,max_phase_error_deg,k1_phase_error_deg,gr_db");
 const int firstFi=argc>2?std::atoi(argv[2]):0;
 const int firstPct=argc>3?std::atoi(argv[3]):0;
 const int firstBias=argc>4?std::atoi(argv[4]):0;
 for(int fi=firstFi;fi<4;++fi){
  const double freq=frequencies[fi],fs=rates[fi];
  const int warm=int(std::lround(fs*(freq<=1000?0.16:0.09)));
  const int N=int(std::lround(fs*(freq==100?0.02:0.01)));
  TGFastZenerLimiter d;d.loadReference(argv[1]);d.prepare(fs);d.setReferenceToneForValidation(freq);
  std::vector<double> x(warm+N), y(N);
  std::vector<std::complex<double>> basis(size_t(N)*20);
  for(int i=0;i<warm+N;++i)x[i]=amp(-18)*sin(2*PI*freq*i/fs);
  for(int h=1;h<=20;++h)for(int i=0;i<N;++i){
   double a=2*PI*freq*h*double(i+warm)/fs;
   basis[size_t(h-1)*N+i]=std::complex<double>(cos(a),-sin(a));
  }
  for(int pct=0;pct<=100;++pct)for(int b=0;b<17;++b){
   if(fi==firstFi&&(pct<firstPct||(pct==firstPct&&b<firstBias)))continue;
   d.setReferenceBiasForValidation(b);
   Controls c;c.inputPct=pct;c.outputPct=50;c.thresholdDb=-8.857143;d.setControls(c);
   d.reset();
   // Independent audio rendering of steady-state gain-cell calibration. The
   // sidechain is precharged to its eventual sine crest, so detector start-up
   // is not mistaken for harmonic distortion (transients tested separately).
   d.primeSteadyDetectorForValidation(amp(-18)*amp(inputDb(pct)+14.));
   for(int i=0;i<warm+N;++i){double v=d.process(x[i]);if(i>=warm)y[i-warm]=v;}
   std::complex<double> harmonics[20]{};
   for(int h=0;h<20;++h){
    const auto *basisHere=&basis[size_t(h)*N];
    for(int i=0;i<N;++i)harmonics[h]+=y[i]*basisHere[i];
    harmonics[h]*=2./N;
   }
   double thdpow=0;
   for(int h=1;h<20;++h)thdpow+=std::norm(harmonics[h]);
   const double thd=std::sqrt(thdpow)/std::max(1e-30,std::abs(harmonics[0]))*100.;
   const auto v1=ref.atIndex(fi,b,pct,1);
   const std::complex<double> r1(v1.re,v1.im);
   double maxerr=0,maxphase=0;
   for(int h=1;h<20;++h){
    const auto vr=ref.atIndex(fi,b,pct,h+1);
    const std::complex<double> r(vr.re,vr.im);
    if(std::abs(r)/std::max(std::abs(r1),1e-30)<1e-7)continue;
    const auto rratio=r/r1;const auto cratio=harmonics[h]/harmonics[0];
    const double aerr=20*std::log10(std::max(std::abs(cratio),1e-30)/std::max(std::abs(rratio),1e-30));
    maxerr=std::max(maxerr,std::abs(aerr));
    maxphase=std::max(maxphase,std::abs(std::arg(cratio/rratio)*180/PI));
   }
   const double k1phase=std::arg(harmonics[0]/r1)*180/PI;
   printf("%.0f,%d,%d,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g\n",freq,pct,b,thd,pct*.02,thd-pct*.02,maxerr,maxphase,k1phase,d.currentGR());
  }
  std::fprintf(stderr,"Completed %gHz: 1717 rendered test points\n",freq);std::fflush(stderr);
 }
}
