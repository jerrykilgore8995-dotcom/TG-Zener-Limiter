#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <complex>
#include <cstdio>
#include <vector>
using namespace tgfast;
int main(int argc,char**argv){
 if(argc<2)return 2;
 for(double f:{100.,1000.,5000.,10000.}){
  TGFastZenerLimiter dsp;dsp.loadReference(argv[1]);dsp.prepare(44100.);
  Controls c;c.inputPct=100;c.thresholdDb=-8.857143;dsp.setControls(c);
  const int settle=44100,ns=44100;
  double k1r=0,k1i=0,k2r=0,k2i=0,k3r=0,k3i=0;
  for(int i=0;i<settle+ns;++i){
    const double y=dsp.process(amp(-18)*std::sin(2*PI*f*i/44100.));
    if(i>=settle){for(int k=1;k<=3;++k){double theta=2*PI*k*f*i/44100.;
      double &rr=(k==1)?k1r:(k==2)?k2r:k3r, &ii=(k==1)?k1i:(k==2)?k2i:k3i;
      rr+=y*cos(theta); ii-=y*sin(theta);}}
  }
  double k1=hypot(k1r,k1i),k2=hypot(k2r,k2i),k3=hypot(k3r,k3i);
  printf("auto freq %.0f Hz K2 %.3f dBc K3 %.3f dBc GR %.3f dB rms %.4g\n",f,20*log10(k2/k1),20*log10(k3/k1),dsp.currentGR(),k1/ns*sqrt(2));
 }
}
