#include "../src/TGFastZenerLimiter.h"
#include <cmath>
#include <cstdio>
#include <stdexcept>
using namespace tgfast;
static double measure(TGFastZenerLimiter& dsp,double sourceDb,double f,double fs){
 double sum=0;int start=int(fs*.3),N=int(fs*.1);
 for(int n=0;n<start+N;++n){double x=amp(sourceDb)*sin(2*PI*f*n/fs);
   double y=dsp.process(x);if(!std::isfinite(y))throw std::runtime_error("nonfinite output");
   if(n>=start)sum+=y*y;}
 return std::sqrt(sum/N);
}
int main(int argc,char**argv){if(argc<2)return 2;
 for(int idx=0;idx<6;++idx){
  TGFastZenerLimiter d;d.loadReference(argv[1]);d.prepare(44100);
  Controls c;c.recovery=idx;c.inputPct=100; d.setControls(c);
  d.setReferenceToneForValidation(1000);
  double rms=measure(d,-18,1000,44100);
  printf("release=%g ms GR=%.6f meter %.2f%% rms=%.8f\n",recoveries[idx],d.currentGR(),100*d.meterFraction(),rms);
  if(std::abs(d.currentGR()-20)>0.03)throw std::runtime_error("20dB calibration failed");
 }
 for(int k=0;k<=10;++k){const double x=k*2.-5.;
  const double gr=grLaw(x,0.,false),y=x-gr;
  if(x>0&&std::abs(y-x/8.)>1e-12)throw std::runtime_error("ratio not 8:1");
 }
 TGFastZenerLimiter d; d.loadReference(argv[1]);d.prepare(44100);
 Controls c;c.inputPct=100;d.setControls(c);
 measure(d,-12,1000,44100);
 if(!(d.currentGR()>20&&d.meterRed()&&d.overRangeDb()>0))throw std::runtime_error("meter overrange missing");
 printf("overload input -12dBFS GR %.4f overrange %.4f\n",d.currentGR(),d.overRangeDb());
 return 0;
}
