#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
GRID="reference/TGZener4Freq_THD2pct_InputScaled.bin"
for t in basic controls program autotrack detector_clean spectra; do
  g++ -std=c++17 -O3 "tests/test_${t}.cpp" -o "build/test_${t}"
  "build/test_${t}" "$GRID" > "build/test_${t}.out"
  echo "PASS: test_${t}"
done
# Optional exhaustive 6,868-case validation: this is CPU intensive and takes
# several minutes due to 10kHz reference sample-rate = 441kHz.
if [[ "${FULL_SWEEP:-0}" == "1" ]]; then
  g++ -std=c++17 -O3 tests/test_full_6868.cpp -o build/test_full_6868
  build/test_full_6868 "$GRID" > build/full_sweep.csv
fi
